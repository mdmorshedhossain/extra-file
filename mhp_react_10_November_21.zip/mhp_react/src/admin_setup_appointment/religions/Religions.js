import React, {Component} from 'react';
import {Link} from 'react-router-dom';

import axios from "axios";
import swal from "sweetalert";

class Religions extends Component
{

    state = {
        religions: [],
        loading:true,
    }


async componentDidMount() {
    const res = await axios.get('http://127.0.0.1:8000/api/religions');
    // console.log(res);

    if (res.data.status === 200)
    {
        this.setState({
            religions: res.data.religions,
            loading:false,
        });
    }
}

    deleteReligion = async (e, id) => {

        const deleteReligionLoad = e.currentTarget;
        deleteReligionLoad.innerText = "Deleting";

        const res = await axios.delete(`http://127.0.0.1:8000/api/delete-religion/${id}`);
        if (res.data.status === 200)
        {
            deleteReligionLoad.closest("tr").remove();
            // console.log(res.data.message);
            swal({
                title: "Deleted!",
                text: res.data.message,
                icon: "success",
                button: "Ok!",
            });

        }
    }


    render() {

        var religion_html_table = "";

        if (this.state.loading)
        {

            religion_html_table = <tr>
                <td colSpan="/"><h2>Loading..</h2></td>
            </tr>;

        }else

        {
            religion_html_table =
                this.state.religions.map((item) => {
                   return (
                       <tr key={item.id}>
                           <td>{item.id}</td>
                           <td>{item.religion_name}</td>
                           <td>{item.created_by}</td>
                           <td>{item.updated_by}</td>
                           <td>{item.created_at}</td>
                           <td>{item.updated_at}</td>
                           <td>
                               <Link to={`edit-religion/${item.id}`} calssName="btn btn-success btn-sm"> <button className="btn btn-primary btn-sm"> Edit </button>  </Link>
                               <button onClick={(e) => this.deleteReligion(e, item.id)} class="btn btn-danger btn-sm"> Delete </button>
                           </td>

                       </tr>
                   );
                });
        }

        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="card-header">
                            <h3 className="card-title">Religions</h3>
                            <div className="float-right">
                                <Link to={'add-religions'} className="btn btn-sm
                                                btn-success float-right"> Add Religion </Link>
                            </div>
                        </div>
                        <div className="card-body">
                            <table id="categories" className="table dataTable no-footer dtr-inline">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Religion Name</th>
                                    <th>Created By</th>
                                    <th>Updated By</th>
                                    <th>Created At</th>
                                    <th>Updated At</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                    {religion_html_table}

                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Religions;