import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import axios from "axios";
import swal from "sweetalert";

class EditReligions extends Component
{

    state = {
        religion_name: '',
        error_list: [],
    }
    handleInput = (e) => {
            this.setState({
                [e.target.name]: e.target.value
            });
    }

    async componentDidMount() {
        const rel_id = this.props.match.params.id;
        // console.log(rel_id);
        const res = await axios.get(`http://127.0.0.1:8000/api/edit-religion/${rel_id}`);

        if (res.data.status === 200 ){
            this.setState({
                religion_name: res.data.religion.religion_name,
            });
        }else if (res.data.status === 404){
            swal({
                title: "Warning!",
                text: res.data.message,
                icon: "warning",
                button: "Ok!",
            });
            this.props.history.push('/');
        }

    }

    updateReligion = async (e) => {
        e.preventDefault();
        // document.getElementById('update_btn').innerText = "Updating";
        const rel_id = this.props.match.params.id;
        const res = await axios.put(`http://127.0.0.1:8000/api/update-religion/${rel_id}`, this.state);

        if (res.data.status === 200)
        {
            // console.log(res.data.message);
            swal({
                title: "Updated!",
                text: res.data.message,
                icon: "success",
                button: "Ok!",
            });

            // document.getElementById('update_btn').innerText = "Update Religion";

            // this.setState({
            //     religion_name: '',
            // });

            this.props.history.push('/');
        }else if (res.data.status === 404)
        {
            swal({
                title: "Warning!",
                text: res.data.message,
                icon: "success",
                button: "Ok!",
            });
            this.props.history.push('/');
        }else
        {
            this.setState({
               error_list: res.data.error_msg,
            });
        }

    }

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="card-header">
                            <h3 className="card-title">Edit Religions</h3>
                            <div className="float-right">
                                <Link to={'/'} className="btn btn-sm
                                                btn-success float-right"> Back </Link>
                            </div>
                        </div>
                        <div className="card-body">
                            <form onSubmit={this.updateReligion}>
                                <div className="card-body">

                                    <div className="col-md-12">

                                        <div className="form-group">
                                            <label htmlFor="religion_name">Religion Name</label>
                                            <input type="text" onChange={this.handleInput} value={this.state.religion_name} className="form-control" name="religion_name"/>
                                            <span className="text-danger">{this.state.error_list.religion_name}</span>
                                        </div>
                                        <div className="float-right">
                                            <button type="submit" id="update_btn" className="btn btn-primary float-right">Update Religion</button>
                                        </div>

                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default EditReligions;