import React, {Component} from 'react';
import {Link} from 'react-router-dom';
import axios from "axios";
import swal from 'sweetalert';

class AddReligions extends Component
{

    state = {
        religion_name: '',
        error_list: [],
    }
    handleInput = (e) => {
            this.setState({
                [e.target.name]: e.target.value
            });
    }

    saveReligion = async (e) => {
        e.preventDefault();

        const res = await axios.post('http://127.0.0.1:8000/api/add-religions', this.state);

        if (res.data.status === 200)
        {
            // console.log(res.data.message);
            swal({
                title: "Success!",
                text: res.data.message,
                icon: "success",
                button: "Ok!",
            });
            this.props.history.push('/');
            this.setState({
                religion_name: '',
            });
        }else{
            this.setState({
               error_list: res.data.error_msg,
            });
        }

    }

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="card-header">
                            <h3 className="card-title">Religions</h3>
                            <div className="float-right">
                                <Link to={'/'} className="btn btn-sm
                                                btn-success float-right"> Back </Link>
                            </div>
                        </div>
                        <div className="card-body">
                            <form onSubmit={this.saveReligion}>
                                <div className="card-body">

                                    <div className="col-md-12">

                                        <div className="form-group">
                                            <label htmlFor="asset_color">Religion Name</label>
                                            <input type="text" onChange={this.handleInput} value={this.state.religion_name} className="form-control" name="religion_name"/>
                                            <span className="text-danger"> {this.state.error_list.religion_name} </span>
                                        </div>
                                        <div className="float-right">
                                            <button type="submit" className="btn btn-primary float-right">Add Religion</button>
                                        </div>

                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default AddReligions;