import React, {Component} from "react";
import {Link} from "react-router-dom";
import axios from "axios";

class AddCountry extends Component
{

    // to catch the data from input fields

    state = {
        country_name: '',
    }

    // handle the input fields

    handleInput = (e) => {
        this.setState({
           [e.target.name]: e.target.value
        });
    }

    // pass data to laravel controller

    saveCountry = async (e) => {
        e.preventDefault();
        const res = await axios.post('http://127.0.0.1:8000/api/save-country',this.state);

        if (res.data.status === 200)
        {
            console.log(res.data.message);
            this.setState({
                country_name: '',
            })

            this.props.history.push('/country');
        }

    }

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="card-header">
                            <h3 className="card-title">Country

                                <Link to={"/"} className="btn btn-primary float-end">Back</Link>

                            </h3>

                        </div>
                        <div className="card-body">
                            <form onSubmit={this.saveCountry}>
                                <div className="card-body">

                                    <div className="col-md-12">

                                        <div className="form-group">
                                            <label htmlFor="asset_color">Country Name</label>
                                            <input type="text" onChange={this.handleInput} value={this.state.country_name} className="form-control" name="country_name"/>
                                        </div>
                                        <div className="float-right">
                                            <button type="submit" className="btn btn-primary float-end mt-4">Add Country</button>
                                        </div>

                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default AddCountry;