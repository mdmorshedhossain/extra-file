import React, {Component} from "react";
import {Link} from "react-router-dom";
import axios from "axios";

class Country extends Component
{

    // pass data to table row
    state = {
        country: [],
        loading: true,
    }


    // get all data from api
    async componentDidMount() {
        const res = await axios.get('http://127.0.0.1:8000/api/country');
        // console.log(res);
        if (res.data.status === 200)
        {
            this.setState({
               country: res.data.country,
                loading: false,
            });
        }

    }

    deleteCountry = async (e, id) =>{

        const deleteCountryLoad = e.currentTarget;
        deleteCountryLoad.innerText = "Deleting";

        const res = await axios.delete(`http://127.0.0.1:8000/api/delete-country/${id}`);

        if (res.data.status === 200)
        {
            // deleteCountryLoad.closest('tr').remove();
            deleteCountryLoad.closest("tr").remove();
            console.log(res.data.message);
        }

    }

    render() {

        var html_table = "";
        if (this.state.loading)
        {
            html_table = <tr>
                <td>Loading..</td>
            </tr>
        }
        else
        {
            html_table =
                this.state.country.map((item) => {
                   return (
                       <tr key={item.id}>
                           <td>{item.id}</td>
                           <td>{item.country_name}</td>
                           <td>{item.created_by}</td>
                           <td>{item.updated_by}</td>
                           <td>{item.created_at}</td>
                           <td>{item.updated_at}</td>
                           <td>
                               <Link to={`edit-country/${item.id}`} class="btn btn-primary btn-sm">Edit</Link>
                               <button onClick={(e) => this.deleteCountry(e, item.id)} className="btn btn-danger btn-sm"> Delete </button>
                           </td>
                       </tr>
                   );
                });
        }

        return (
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <div className="card-header">
                        <h3 className="card-title">Country
                            <Link to={'add-country'} className="btn btn-primary btn-sm float-end"> Add Country </Link>
                        </h3>
                    </div>
                    <div className="card-body">
                        <table id="categories" className="table dataTable no-footer dtr-inline">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Country Name</th>
                                <th>Created By</th>
                                <th>Updated By</th>
                                <th>Created At</th>
                                <th>Updated At</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>

                                    {html_table}

                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
        );
    }
}

export default Country;