import React, {Component} from "react";
import {Link} from "react-router-dom";
import axios from "axios";

class EditCountry extends Component
{
    state = {
        country_name: '',
    }

    handleInput = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
    }

    async componentDidMount() {
        const country_id = this.props.match.params.id;
        // console.log(country_id);
        const res = await axios.get(`http://127.0.0.1:8000/api/edit-country/${country_id}`);

        if (res.data.status === 200)
        {
            this.setState({
                country_name: res.data.country.country_name,
            });
        }
    }

    updateCountry = async (e) => {
        e.preventDefault();
        const country_id = this.props.match.params.id;
        const res = await axios.put(`http://127.0.0.1:8000/api/update-country/${country_id}`, this.state);

        if (res.data.status === 200)
        {
            // console.log(res);
            // this.setState({
            //    country_name: '',
            // });
         this.props.history.push('/country');
        }
    }

    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <div className="card-header">
                            <h3 className="card-title">Edit Country</h3>
                            <div className="float-right">
                                <Link to={'/country'} className="btn btn-sm
                                                btn-success float-right"> Back </Link>
                            </div>
                        </div>
                        <div className="card-body">
                            <form onSubmit={this.updateCountry}>
                                <div className="card-body">

                                    <div className="col-md-12">

                                        <div className="form-group">
                                            <label htmlFor="country_name">Country Name</label>
                                            <input type="text" onChange={this.handleInput} value={this.state.country_name} className="form-control" name="country_name"/>
                                        </div>
                                        <div className="float-right">
                                            <button type="submit" id="update_btn" className="btn btn-primary float-end mt-3">Update Country</button>
                                        </div>

                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default EditCountry;