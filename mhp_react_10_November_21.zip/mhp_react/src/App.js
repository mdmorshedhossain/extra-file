import React from 'react';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';

import Religions from "./admin_setup_appointment/religions/Religions";
import AddReligions from "./admin_setup_appointment/religions/AddReligions";
import EditReligions from "./admin_setup_appointment/religions/EditReligions";
import Country from "./admin_setup_appointment/country/Country";
import AddCountry from "./admin_setup_appointment/country/AddCountry";
import EditCountry from "./admin_setup_appointment/country/EditCountry";

function App() {
  return (
      <Router>
        <Switch>
          <Route exact path="/" component={Religions} />
          <Route path="/add-religions" component={AddReligions} />
          <Route path="/edit-religion/:id" component={EditReligions} />
          <Route path="/country" component={Country} />
          <Route path="/add-country" component={AddCountry}/>
          <Route path="/edit-country/:id" component={EditCountry}/>

        </Switch>
      </Router>
  );
}

export default App;
